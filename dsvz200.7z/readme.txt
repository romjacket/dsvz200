DSVZ200
VZ200 Developers System
 
"With its powerful 16K BASIC the VZ200 is fine for serious computing."

This emulator was written from scratch by one person entirely in assembly language, file formats and peripheral emulation have been determined by painstakingly analyzing disassembled routines. The central processor emulation uses the binary decoding method and emulates the undocumented opcodes and flag bits.
There are no software dependencies, no prerequisites to the automatic installation, the software rendering does not rely on additional libraries and google searching downloads to function, instead the focus is on ready to use software and wider target compatibility.

 No license agreements 
 No conditions of use 
 No software dependencies 
 No installation prerequisites 
 No third party libraries 


Mission Impossible


The mission should I decide to take it (because the pay is low !) is emulate my first computer, the VZ200 to accuracy of extreme levels and not just the central processor and video generator, it must sound like there really is a piezo speaker inside and it should be rendered clearly with familiar green colour tones on real bitmaps instead of an eye gouging filtered simulation.

Simple Program Entry


The package includes a useful code editor that can process BASIC programs, Assembler or BASIC combined with assembler subroutines into a single cassette tape image file this useful tool can even be used to enter entire BASIC programs without using the emulator at all to input programs free to copy paste and find in the modern and more advanced windows GUI environment.

Target Hardware


This software produces object code that will run on a stock standard VZ200 directly in emulator image format that can be transferred with a simple aux cable this means just a bare VZ200 unit is enough hardware the other accessories are readily avaliable generic items.
Mythbusting

1. The VZ200 runs on 10 volts not 12 Volts (as reported by wikipedia, until it was corrected recently many VZ200 overheated and burnt out !).
2. The original VZ200 box shamelessly shows a hidden Dick Smith Wizard hooked up to the TV Set with a cable-less VZ200 in front of the TV.
3. The 2-1/2 octave sound/Music facility is really a cheap piezo disc.
4. The 9 colours are Red, Yellow and Blue.



IO Port

00 - 0F Printer
10 - 1F Floppy Disk Controller
20 - 2F Joystick Interface
30 - 3F Modem
40 - 4F Light Pen
70 - 7F Memory Bank Page
D0 - DF Graphics Control


Memory Maps

Laser xx0
0000-3FFF 16K BASIC ROM
4000-5FFF 8K DOS ROM
6000-67FF 2K ROM Cartridge
6800-6FFF 2K I/O (Read: keyboard) (Write: cass,speaker,VDC)
7000-77FF 2K Video RAM
7800-7AE8 System Reserved RAM

Laser 110
7800-7FFF 2K internal user RAM
8000-BFFF 16K memory expansion

Laser 210
7800-8FFF 6K internal user RAM
9000-CFFF 16K memory expansion

Laser 310
7800-B7FF 16K internal user RAM
B800-F7FF 16K memory expansion
Split Screen II by GsTsoftware
             ORG $7B00
             DEFW SPLITSCREEN ;Activate SplitScreen & CLS
             DEFW SPLITNOCLS  ;Activate SplitScreen No CLS
             DEFW SPLITOFF    ;Turn Off Split Screen
SPLIT:
             DI
             JP ENTRY
SPLITSCREEN:
             DI
             LD HL,$7000
             LD B,$80
             LD D,$60
SP2_CLS0:    LD (HL),D    ;CLS Text Memory
             INC HL
             DJNZ SP2_CLS0
             LD D,$0
             LD A,$6
SP2_CLS:     LD (HL),D    ;CLS Graphics Memory
             INC HL
             DJNZ SP2_CLS
             DEC A
             JR NZ,SP2_CLS
SPLITNOCLS:
             DI
             LD A,$33     ;Int Vector Low
             LD ($787E),A ;
             LD A,$7B     ;Int Vector High
             LD ($787F),A ;
             LD A,$C3     ;"JMP"
             LD ($787D),A ;Enable Split
             EI           ;
             RET
SPLIT_MAIN:
             LD A,$0       ;
             LD ($6800),A  ;Set Video Mode
             LD A,$ED
SP2_DELAY0:  LD B,$B       ;Delay Loop
SP2_DELAY1:  DJNZ SP2_DELAY1;
             DEC A          ;
             JR NZ,SP2_DELAY0;
             LD A,$8
             LD ($6800),A   ;Set Video Mode
             RET
SPLITOFF:
             DI
             LD A,$C9     ;"RET"
             LD ($787D),A ;Turn Off Split
             EI           ;
             RET
ENTRY:
             CALL SPLITSCREEN
             RET
